#include "min-spanning-tree.h"

// -------------------- MSP computation -------------------- //
edge_t *kruskal(city_node_t *vertices, unsigned n)
{
    fprintf(stderr,"La fonction 'kruskal' n'est pas implementee! Exit...\n");
    exit(1);
}

edge_t *prim(city_node_t *vertices, unsigned n)
{
    fprintf(stderr,"La fonction 'prim' n'est pas implementee! Exit...\n");
    exit(1);
}
