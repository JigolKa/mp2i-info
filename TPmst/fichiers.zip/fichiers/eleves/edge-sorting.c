#include "edge-sorting.h"

static void swap_edges(edge_t *e1, edge_t *e2)
{
    edge_t tmp = *e1;

    e1->ID_1 = e2->ID_1;
    e1->ID_2 = e2->ID_2;
    e1->weight = e2->weight;

    e2->ID_1 = tmp.ID_1;
    e2->ID_2 = tmp.ID_2;
    e2->weight = tmp.weight;
}

void on_place_edge_sort(edge_t* edge_arr, unsigned n)
{
    fprintf(stderr,"La fonction 'on_place_edge_sort' n'est pas implementee! Exit...\n");
    exit(1);
}
