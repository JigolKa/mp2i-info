#include "union-find.h"


union_find uf_create(size_t n)
{
    fprintf(stderr,"La fonction 'uf_create' n'est pas implementee! Exit...\n");
    exit(1);
}

void uf_delete(union_find u)
{
    fprintf(stderr,"La fonction 'uf_deletee' n'est pas implementee! Exit...\n");
    exit(1);
}

size_t uf_parent(union_find u, size_t x)
{
    fprintf(stderr,"La fonction 'uf_parent' n'est pas implementee! Exit...\n");
    exit(1);
}

bool uf_is_root(union_find u, size_t x)
{
    fprintf(stderr,"La fonction 'uf_is_root' n'est pas implementee! Exit...\n");
    exit(1);
}

size_t uf_find(union_find u, size_t x)
{
    fprintf(stderr,"La fonction 'uf_find' n'est pas implementee! Exit...\n");
    exit(1);
}

size_t uf_unite(union_find u, size_t x, size_t y)
{
    fprintf(stderr,"La fonction 'uf_unite' n'est pas implementee! Exit...\n");
    exit(1);
}
